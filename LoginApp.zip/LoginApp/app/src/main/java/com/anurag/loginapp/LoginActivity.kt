package com.anurag.loginapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth

class LoginActivity : AppCompatActivity() {
    lateinit var email:EditText
    lateinit var pass:EditText
    private lateinit var mAuth: FirebaseAuth
    lateinit var signup:TextView
    lateinit var button: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        title="Login Page"
        email=findViewById(R.id.etloginemail)!!
        pass=findViewById(R.id.etloginpass)
        button=findViewById(R.id.btnlogin)
        signup=findViewById(R.id.txtsignup)
        mAuth= FirebaseAuth.getInstance()
        button.setOnClickListener {
            createUser();
        }
        signup.setOnClickListener {
            val intent=Intent(this@LoginActivity,SignUpActivity::class.java)
            startActivity(intent)
        }
    }
    private fun createUser() {
    var email=email.text.toString()
    var pass=pass.text.toString()
    if(!email.isEmpty() && Patterns.EMAIL_ADDRESS.matcher(email).matches())
    {
        if(!pass.isEmpty())
        {
            mAuth.signInWithEmailAndPassword(email,pass).addOnCompleteListener {
                Toast.makeText(this@LoginActivity,"Login Successfully !!",Toast.LENGTH_SHORT).show()
                val intent=Intent(this@LoginActivity,MainActivity::class.java)
                startActivity(intent)
                finish()
            }
        }else{
           this.email.setError("Empty Fields are not allowed")
        }
    }
    else if(email.isEmpty()){
        this.email.setError("Empty Fields are not allowed")
    }else{
        this.email.setError("Empty Fields are not allowed")
    }
    }
}