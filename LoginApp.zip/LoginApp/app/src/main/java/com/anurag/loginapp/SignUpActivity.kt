package com.anurag.loginapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth

class SignUpActivity : AppCompatActivity() {
    lateinit var email:EditText
    lateinit var pass :EditText
    lateinit var button: Button
    private lateinit var mAuth:FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signuppage)
        email=findViewById(R.id.etsignemail)
        pass=findViewById(R.id.etsignpass)
        button=findViewById(R.id.btnsignup)
        title="Sign In Page"
        mAuth= FirebaseAuth.getInstance()
        button.setOnClickListener {
            loginuser()
        }
    }
    private fun loginuser()
    {
        var gemail=email.text.toString()
        var gpass=pass.text.toString()
        if(!gemail.isEmpty() && Patterns.EMAIL_ADDRESS.matcher(gemail).matches())
        {
            if(!gpass.isEmpty())
            {
                mAuth.createUserWithEmailAndPassword(gemail,gpass).addOnSuccessListener {
                    Toast.makeText(this@SignUpActivity,"Registered Successfully !!",Toast.LENGTH_SHORT).show()
                val intent=Intent(this@SignUpActivity,MainActivity::class.java)
                    startActivity(intent)
                    finish()
                }.addOnFailureListener {
                    Toast.makeText(this@SignUpActivity,"Registration Failed !!",Toast.LENGTH_SHORT).show()
                }
            }else{
                email.setError("Empty Fields are not allowed")
            }
        }
        else if(gemail.isEmpty()){
            email.setError("Empty Fields are not allowed")
        }else{
            email.setError("Empty Fields are not allowed")
        }
    }
}